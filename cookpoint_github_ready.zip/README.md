# CookPoint Delivery Bag Frontend

Frontend listo para subir a GitHub Pages.

## Estructura
- index.html
- styles.css

## Deploy en GitHub Pages
1. Crear repo nuevo
2. Subir archivos
3. Settings > Pages > Deploy from branch
4. Seleccionar main y carpeta root
5. Guardar

